---
title: Spotify Recommendation System
emoji: 📊
colorFrom: red
colorTo: gray
sdk: streamlit
sdk_version: 1.10.0
app_file: main.py
pinned: false
---
Check out the Github repository for more info: [Spotify-Recommendation-System](https://github.com/abdelrhmanelruby/Spotify-Recommendation-System)

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
